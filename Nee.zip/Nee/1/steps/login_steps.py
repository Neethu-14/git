from behave import given, when, then
from pages.login_page import LoginPage

@given("user is on login page")
def step_open_login(context):
    context.login = LoginPage()
    context.login.open_login_page()

@when("user enters valid credentials")
def step_login(context):
    context.login.login("test@email.com", "test1234")

@then("user should be logged in successfully")
def step_verify_login(context):
    assert context.login.is_logged_in() == True

from behave import given, when, then
from pages.contact_page import ContactPage

@given("user is logged in")
def step_user_logged_in(context):
    context.contact = ContactPage()

@when("user creates a new contact")
def step_create_contact(context):
    context.contact.create_contact()

@then("contact should be created successfully")
def step_verify_contact(context):
    assert context.contact.verify_contact_created() == True

class LoginPage:

    def open_login_page(self):
        print("Opening login page")

    def login(self, email, password):
        print(f"Logging in with {email}")

    def is_logged_in(self):
        return True

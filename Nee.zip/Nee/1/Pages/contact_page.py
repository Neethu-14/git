class ContactPage:

    def create_contact(self):
        print("Creating contact")

    def verify_contact_created(self):
        return True

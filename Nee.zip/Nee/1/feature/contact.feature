@regression
Scenario: Edit contact details
  Given user is logged in
  When user edits a contact
  Then contact details should be updated

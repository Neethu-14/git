def before_all(context):
    print("Test execution started")

def after_all(context):
    print("Test execution completed")

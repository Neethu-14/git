import pandas as pd

def read_contacts(file_path):
    return pd.read_excel(file_path)
